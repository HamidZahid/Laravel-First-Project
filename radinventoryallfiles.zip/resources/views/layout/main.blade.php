@include('layout.header')
@include('layout.navbar')
<div class="container-fluid">
 @yield('main-section')
</div>
@include('layout.footer')

