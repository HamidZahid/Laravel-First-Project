<?php $__env->startSection('main-section'); ?>
<div class="text-center">
Hellow World
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\radinventory\resources\views/welcome.blade.php ENDPATH**/ ?>