<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<aside class="sidebar py-5">
    <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
            <span></span>
        </a>
    </div>
    <div class="side-inner">
        <div class="profile">
            <img src="images/person_4.jpg" alt="Image" class="img-fluid">
            <h3 class="name">Craig David</h3>
            <span class="country">Web Designer</span>
        </div>
        <div class="nav-menu">
            <ul>
                <li class="accordion">
                    <a href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false"
                        aria-controls="collapseOne" class="collapsible">
                        <span class="icon-user mr-3"></span>Add Customer
                    </a>
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne">
                        <div>
                            <ul>
                                <li><a href="<?php echo e(url('add-customer')); ?>">Add Customer</a></li>
                                <li><a href="#">Sport</a></li>
                                <li><a href="#">Health</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="accordion">
                    <a href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"
                        aria-controls="collapseTwo" class="collapsible">
                        <span class="icon-user mr-3"></span>Add Supplier
                    </a>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingOne">
                        <div>
                            <ul>
                                <li><a href="<?php echo e(url('add-supplier')); ?>">Add Supplier</a></li>
                                <li><a href="#">Food</a></li>
                                <li><a href="#">Travel</a></li>
                            </ul>
                        </div>
                    </div>

                </li>
                <li><a href="<?php echo e(url('bills')); ?>"><span class="icon-notifications mr-3"></span>Bills</a></li>
                <li><a href="<?php echo e(url('leads')); ?>"><span class="icon-location-arrow mr-3"></span>Leads</a></li>
                <li><a href="<?php echo e(url('new-po')); ?>"><span class="icon-pie-chart mr-3"></span>New PO</a></li>
                <li><a href="<?php echo e(url('payment-recieved')); ?>"><span class="icon-pie-chart mr-3"></span>Payment Recieved</a></li>
                <li><a href="<?php echo e(url('payment')); ?>"><span class="icon-pie-chart mr-3"></span>Payment</a></li>
                <li><a href="<?php echo e(url('purchase-order')); ?>"><span class="icon-pie-chart mr-3"></span>Purchase Order</a></li>
                <li><a href="<?php echo e(url('supplier-list')); ?>"><span class="icon-pie-chart mr-3"></span>Supplier List</a></li>
                <li><a href="<?php echo e(url('vendor-list')); ?>"><span class="icon-pie-chart mr-3"></span>Vendor List</a></li>
                <li><a href="<?php echo e(url('groups')); ?>"><span class="icon-users mr-3"></span>Groups</a></li>
                <li><a href="<?php echo e(url('unpaidinvoice')); ?>"><span class="icon-users mr-3"></span> UnPaid Voice</a></li>
                <li><a href="<?php echo e(url('unpaidexpenseinvoice')); ?>"><span class="icon-users mr-3"></span> UnPaid Expense Voice</a></li>
                <li><a href="<?php echo e(url('unclearedtransaction')); ?>"><span class="icon-users mr-3"></span> Uncleared Transaction</a></li>
                <li><a href="<?php echo e(url('transaction')); ?>"><span class="icon-users mr-3"></span> Transaction</a></li>
                <li><a href="<?php echo e(url('salesinvoice')); ?>"><span class="icon-users mr-3"></span> Sales Invoice</a></li>
                <li><a href="<?php echo e(url('recurringinvoices')); ?>"><span class="icon-users mr-3"></span> Recurring Invoices</a></li>
                <li><a href="<?php echo e(url('newquote')); ?>"><span class="icon-users mr-3"></span> New Quote</a></li>
                <li><a href="<?php echo e(url('newsalesinvoice')); ?>"><span class="icon-users mr-3"></span> New Sales Invoice</a></li>
                <li><a href="<?php echo e(url('newtransfer')); ?>"><span class="icon-users mr-3"></span> New Transfer</a></li>
                <li><a href="<?php echo e(url('paidcustomers')); ?>"><span class="icon-users mr-3"></span> Paid Customers</a></li>
                <li><a href="<?php echo e(url('paidexpenses')); ?>"><span class="icon-users mr-3"></span> Paid Expenses</a></li>
                <li><a href="<?php echo e(url('PaidInvoice')); ?>"><span class="icon-users mr-3"></span> Paid Invoice</a></li>
                <li><a href="<?php echo e(url('managecategories')); ?>"><span class="icon-users mr-3"></span> Manage Categories</a></li>
                <li><a href="<?php echo e(url('manageaccounts')); ?>"><span class="icon-users mr-3"></span> Manage Accounts</a></li>
                <li><a href="<?php echo e(url('deadstock')); ?>"><span class="icon-users mr-3"></span> Dead Stock</a></li>
                <li><a href="<?php echo e(url('edittransaction')); ?>"><span class="icon-users mr-3"></span> Edit Transaction</a></li>
                <li><a href="<?php echo e(url('expireproductlist')); ?>"><span class="icon-users mr-3"></span> Expire Product list</a></li>
                <li><a href="<?php echo e(url('addexpense')); ?>"><span class="icon-users mr-3"></span> Add Expense</a></li>
                <li><a href="<?php echo e(url('addnewaccount')); ?>"><span class="icon-users mr-3"></span> Add New Account</a></li>
                <li><a href="<?php echo e(url('addsupplier')); ?>"><span class="icon-users mr-3"></span> Add Supplier</a></li>
                <li><a href="<?php echo e(url('addwarehouse')); ?>"><span class="icon-users mr-3"></span> Add Warehouse</a></li>
                <li><a href="<?php echo e(url('assets')); ?>"><span class="icon-users mr-3"></span> Assets</a></li>
                
                <li><a href="#"><span class="icon-sign-out mr-3"></span>Sign out</a></li>
            </ul>
        </div>
    </div>

</aside>


<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\radinventory\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>